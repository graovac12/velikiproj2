<?php

defined( 'ABSPATH' ) || exit;

/**
 * Template Page Break
 *
 * This template can be overridden by copying it to yourtheme/themify-builder/template-page-break.php.
 *
 * Access original fields: $args['mod_settings']
 * @author Themify
 */
?>
<!-- module page break -->
<div class="tb-page-break-pagination"></div>
<!-- /module page break -->
