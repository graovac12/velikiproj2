<?php
/**
 * Intermediate template for search. Calls index.php template.
 * @package themify
 * @since 1.0.0
 */
get_template_part( 'index','search');